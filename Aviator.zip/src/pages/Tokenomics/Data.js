export const data =
    {
        names: ["Burned tokens","Treasury Supply","Marketing Wallet","Uniswap Supply","Circulating Supply","Team Lock"],
        values: [10,12,33,25,13,7],
        color: ["#DB9A2480", "#B69A4980", "#929B6D80","#6D9C9280","#499DB680","#249DDB80"],
        strokeColor: ["#DB9A24", "#B69A49", "#929B6D","#6D9C92","#499DB6","#249DDB"],
    }
   