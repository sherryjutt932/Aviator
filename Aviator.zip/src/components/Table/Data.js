export const data = [
    {
        id:"001",
        date:"11/12/23",
        hash:"sc8aus9na",
        amount:220.43,
        detail:"axasknlax",
        status: "edited"
    },
    {
        id:"002",
        date:"11/12/23",
        hash:"sc8aus9na",
        amount:30.33,
        detail:"axasknlax",
        status: "edited"
    },
    {
        id:"003",
        date:"11/12/23",
        hash:"sc8aus9na",
        amount:1389.2,
        detail:"axasknlax",
        status: "new"
    },
    {
        id:"004",
        date:"11/12/23",
        hash:"sc8aus9na",
        amount:862.33,
        detail:"axasknlax",
        status: "edited"
    },
    {
        id:"005",
        date:"11/12/23",
        hash:"sc8aus9na",
        amount:220.43,
        detail:"axasknlax",
        status: "new"
    },
    {
        id:"005",
        date:"11/12/23",
        hash:"sc8aus9na",
        amount:220.43,
        detail:"axasknlax",
        status: "edited"
    },
    {
        id:"006",
        date:"11/12/23",
        hash:"sc8aus9na",
        amount:30.33,
        detail:"axasknlax",
        status: "edited"
    },
]