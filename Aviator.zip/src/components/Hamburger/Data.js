export const data = [
    {
        label:"About Aviator",
        url:"",
    },
    {
        label:"Tokenomics",
        url:"Tokenomics",
    },
    {
        label:"Roadmap",
        url:"Roadmap",
    },
    {
        label:"Flightpaper",
        url:"Flightpaper",
    },
    {
        label:"Skybridge",
        url:"Skybridge",
    },
    {
        label:"Aviator Arcade",
        url:"AviatorArcade",
    },
]